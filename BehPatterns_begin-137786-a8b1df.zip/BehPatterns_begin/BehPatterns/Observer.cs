﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BehPatterns
{    
    public class NewsPublisher
    {
        private readonly List<string> _news = new List<string>();
        //private readonly List<ISubscriber> _subscribers = new List<ISubscriber>();
        public event Action<string> NewsArrived;

        public void Add(string news)
        {
            _news.Add(news);
            NewsArrived?.Invoke(news);            
            //foreach(var subscriber in _subscribers)
            //{
            //    subscriber.NewsArrived(news);
            //}
        }

        //public void SubscribeMe(ISubscriber subscriber)
        //{
        //    _subscribers.Add(subscriber);
        //}

        //public void UnsubscribeMe(ISubscriber subscriber)
        //{
        //    _subscribers.Remove(subscriber);
        //}
    }

    //public interface ISubscriber
    //{
    //    void NewsArrived(string news);
    //}

    public class Person//: ISubscriber
    {
        public string Name { get; set; }

        public void NewsArrived(string news)
        {
            //if (Name == "Ivan")
            //{
            //    throw new Exception("Не умею обрабывать");
            //}
            Console.WriteLine($"Я {Name} получил новость {news}");
        }
    }
}
