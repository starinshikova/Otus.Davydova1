﻿using System;
using System.IO;

namespace BehPatterns
{
    class MailExporter : MyExporter
    {
        public MailExporter(string data):base(data)
        {
        }

        protected override string PackFile(string filePath)
        {
            return "1.zip";
        }

        protected override void Send(string packedFile)
        {
            // TODO: send mail;
        }
    }

    class FtpExporter : MyExporter
    {
        public FtpExporter(string data) : base(data)
        {
        }

        protected override string PackFile(string filePath)
        {
            return "1.tg";
        }

        protected override void Send(string packedFile)
        {
            // TODO: send ftp;
        }
    }

    abstract class MyExporter
    {
        private readonly string _data;

        public MyExporter(string data)
        {
            _data = data;
        }

        public void ExportData()
        {
            // создать файл
            var filePath = CreateFile();
            // записать в него данные
            WriteData(filePath);
            // упаковать файл
            var packedFile = PackFile(filePath);
            // отправить по почте
            Send(packedFile);
            // удалить файлы
            DeleteFiles(filePath, packedFile);
        }

        private void DeleteFiles(string filePath, string packedFile)
        {
            File.Delete(filePath);
            File.Delete(packedFile);
        }

        protected virtual void Send(string packedFile)
        {
            // TODO: send mail
        }

        protected virtual string PackFile(string filePath)
        {
            return "1.zip";
        }

        private void WriteData(string filePath)
        {
            // FilePath <- _data
        }

        private string CreateFile()
        {
            return "1.txt";
        }
    }
}
