﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace BehPatterns.Visitor
{
    class Visitor
    {
        public void Visit()
        {
            var storage = new Storage();
            var consoleWriteLineVisitor = new ConsoleWritelineVisitor();
            foreach (Item item in storage)
            {
                item.Process(consoleWriteLineVisitor);
            }
        }
    }

    class ConsoleWritelineVisitor : IVisitor
    {
        public void Process(SimpleItem item)
        {
            Console.WriteLine(item.Data.ToString());
        }

        public void Process(ComplexItem item)
        {
            Console.WriteLine(item.Data.ToString() + " _ " + item.Data2.ToString());
        }
    }

    class FileWritelineVisitor : IVisitor
    {
        public void Process(SimpleItem item)
        {
            File.WriteAllText("1.txt", item.Data.ToString());
        }

        public void Process(ComplexItem item)
        {
            File.WriteAllText("1.txt", item.Data.ToString() + " _ " + item.Data2.ToString());
        }
    }

    interface IVisitor
    {
        void Process(SimpleItem item);
        void Process(ComplexItem item);
    }

    class StorageEnumerator : IEnumerator<Item>
    {
        private readonly Storage _storage;

        public StorageEnumerator(Storage storage)
        {
            _storage = storage;
        }

        private char _current = (char)('a' - 1);

        public Item Current
        {
            get
            {
                switch (_current)
                {
                    case 'a': return _storage.A;
                    case 'b': return _storage.B;
                    case 'c': return _storage.C;
                    case 'd': return _storage.D;
                    case 'e': return _storage.E;
                    default: return null;
                }
            }
        }

        object IEnumerator.Current => Current;

        public void Dispose()
        {
        }

        public bool MoveNext()
        {
            var current = _current + 1;
            if (current > 'e')
            {
                return false;
            }
            _current = (char)current;
            return true;
        }

        public void Reset()
        {
            _current = (char)('a' - 1);
        }
    }

    class Storage : IEnumerable<Item>
    {
        public Item A { get; }
        public Item B { get; }
        public Item C { get; }
        public Item D { get; }
        public Item E { get; }

        public Storage()
        {
            A = new SimpleItem(1);
            B = new ComplexItem(2, 20);
            C = new SimpleItem(17);
            D = new ComplexItem(45, 450);
            E = new SimpleItem(54);
        }

        public IEnumerator<Item> GetEnumerator()
        {
            return new StorageEnumerator(this);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }

    abstract class Item
    {
        public int Data { get; }

        public Item(int data)
        {
            Data = data;
        }

        public abstract void Process(IVisitor visitor);        
    }

    class SimpleItem : Item
    {
        public SimpleItem(int data) : base(data)
        {
        }

        public override void Process(IVisitor visitor)
        {
            visitor.Process(this);
        }
    }

    class ComplexItem : Item
    {
        public int Data2 { get; }

        public ComplexItem(int data, int data2) : base(data)
        {
            Data2 = data2;
        }

        public override void Process(IVisitor visitor)
        {
            visitor.Process(this);
        }
    }
}
