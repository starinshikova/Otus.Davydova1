﻿using System;

namespace BehPatterns
{
    //class Program
    //{
    //    private WithdrawService _context = new WithdrawService(new SberWithdrawStrategy());
        
    //    void SetWithdawMethod()
    //    {
    //        _context.SetStrategy(...)
    //    }

    //    void Withdraw(decimal amount)
    //    {
    //        _context.ValidateAmount(amount);
    //        _context.Withdraw();
    //    }
    //}

    class WithdrawService: WithdrawStrategy
    {
        private WithdrawStrategy _strategy;

        public WithdrawService(WithdrawStrategy strategy)
        {
            _strategy = strategy;
        }        

        public void SetStrategy(WithdrawStrategy strategy)
        {
            _strategy = strategy;
        }

        public void ValidateAmount(decimal amount)
        {
            _strategy.ValidateAmount(amount);
        }

        public decimal GetAmountToDecrease(decimal amount)
        {
            return _strategy.GetAmountToDecrease(amount);
        }
    }

    interface WithdrawStrategy
    {
        void ValidateAmount(decimal amount);

        decimal GetAmountToDecrease(decimal amount);        
    }

    class SberWithdrawStrategy: WithdrawStrategy
    {
        public void ValidateAmount(decimal amount)
        {
            // любая сумма больше 100
            if (amount <= 100)
            {
                throw new Exception("Wrong!");
            }
        }

        public decimal GetAmountToDecrease(decimal amount)
        {
            // 5% накидываем сверху
            return amount * (decimal)1.05;
        }

        public void Withdraw(decimal amount)
        {
            // выполнить сам вывод
        }
    }

    class AlfaWithdrawStrategy
    {
        public void ValidateAmount(decimal amount)
        {
            // любая сумма больше 500
            if (amount <= 500)
            {
                throw new Exception("Wrong!");
            }
        }

        public decimal GetAmountToDecrease(decimal amount)
        {
            // 7% накидываем сверху
            return amount * (decimal)1.07;
        }

        public void Withdraw(decimal amount)
        {
            // выполнить сам вывод
        }
    }

    class VtbWithdrawStrategy
    {
        public void ValidateAmount(decimal amount)
        {
            // любая сумма больше 100
            if (amount <= 100)
            {
                if (amount % 25 != 0)
                {
                    throw new Exception("Wrong!");
                }
            }
        }

        public decimal GetAmountToDecrease(decimal amount)
        {
            // 3% накидываем сверху
            return amount * (decimal)1.03;
        }

        public void Withdraw(decimal amount)
        {
            // выполнить сам вывод
        }
    }
}
