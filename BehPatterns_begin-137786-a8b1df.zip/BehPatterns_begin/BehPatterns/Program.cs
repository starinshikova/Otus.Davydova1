﻿using System;

namespace BehPatterns
{
    class Program
    {
        static void Main(string[] args)
        {
            //var iterator = new Iterator();
            //iterator.Iterate();

            //var visitor = new Visitor.Visitor();
            //visitor.Visit();

            var newsPublisher = new NewsPublisher();

            var ivan = new Person
            {
                Name = "Ivan"
            };
            var petr = new Person
            {
                Name = "Petr"
            };

            try
            {
                newsPublisher.Add("Пропущенная новость");
            } 
            catch
            {

            }
            //newsPublisher.SubscribeMe(ivan);
            newsPublisher.NewsArrived += ivan.NewsArrived;            
            try
            {
                newsPublisher.Add("Новость 1");            
            } 
            catch
            {

            }
            //newsPublisher.SubscribeMe(petr);
            newsPublisher.NewsArrived += petr.NewsArrived;            
            try 
            { 
                newsPublisher.Add("Новость 2");
            }
            catch
            {

            }

            Console.ReadKey();
        }
    }
}
